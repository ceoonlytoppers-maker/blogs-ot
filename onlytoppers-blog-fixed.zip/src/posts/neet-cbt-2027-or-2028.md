---
title: "NEET CBT Mode: 2027 or 2028? Latest Update & How to Prep"
description: "Is NEET going CBT in 2027 or 2028? Here's what's reported, what's still unofficial, and how to prep for both pen-and-paper and computer-based tests."
date: 2026-11-07
updated: 2026-11-07
permalink: /neet-cbt-2027-or-2028/
author: OnlyToppers Editorial Team
category: NEET
tags:
  - NEET 2027
  - NEET CBT
  - NEET preparation
keywords: NEET 2027 CBT mode, NEET 2027 computer based test, NEET CBT vs pen and paper, NEET 2027 normalisation, NEET CBT mock test
layout: layouts/post.njk
---

# NEET CBT Mode: 2027 or 2028? Latest Update & How to Prep

**Last updated: 7 November 2026**

Your feed is probably full of "NEET is going online" reels. Some say 2027. Some say 2028. Some say "hybrid". Let's sort the noise from the facts in about 5 minutes, then get you a prep plan that works either way.

## TL;DR

- NEET UG moving to a **computer-based test (CBT)** has been announced by the Centre and NTA.
- The **start year is not confirmed**. Fresh reports say 2027 may stay pen-and-paper (or run as a hybrid), with full CBT likely from 2028.
- The Nandan Nilekani-led exam reform task force has had its tenure extended to **27 January 2027**. The final call is expected after its report.
- Syllabus, shifts, marking and normalisation details are **not officially announced**.
- Smart move: prep for **both** formats. Your concepts matter far more than the mode.

## Wait, so is NEET 2027 CBT or not?

Here's the timeline in plain words.

After the NEET UG 2026 paper leak controversy, the Centre announced that NEET would move from OMR to computer-based testing. NTA later told the Supreme Court the same thing, and reports talked about a multi-day exam across around 1,000 centres.

Then, in early November 2026, newer reports said the plan may be slower than expected:

- Officials reportedly feel big changes are hard to roll out in time for a May 2027 exam.
- Some southern states, including Tamil Nadu, Kerala and Karnataka, have raised concerns about infrastructure and access for rural students.
- A hybrid setup (some pen-and-paper, some CBT) has been reported as an option for 2027, with the full shift in the 2028-29 cycle.

Important: these are **reports citing sources**, not an official NTA notification. Until NTA publishes the bulletin, treat everything as "likely", not "locked".

## Confirmed vs reported vs unknown

| Status | What we know |
|---|---|
| Announced | NEET UG is planned to move to CBT |
| Reported, unconfirmed | 2027 may be pen-and-paper or hybrid, full CBT from 2028 |
| Reported, unconfirmed | Multi-day CBT across roughly 1,000 centres |
| Pending | Task force report (due by 27 Jan 2027) and NTA's official bulletin |
| Not announced | Exact dates, shifts, marking scheme, normalisation method |

Screenshot this table. Next time someone in a Telegram group says "my cousin's friend knows the exact pattern", you have receipts.

## Will CBT make NEET harder?

No. Changing the mode doesn't change how tough a Physics numerical or a Biology question is. Your concepts decide your score.

What can feel different at first:

- Reading long questions on a screen
- Moving between questions without flipping pages
- Tracking time with an on-screen timer
- Doing calculations on rough sheets while looking at a monitor

That's a **practice gap**, not a difficulty jump. You can close it in a few weeks.

## Shifts and normalisation: what to know

If a CBT exam runs over several days, different papers may need a fair way to compare scores. That's what normalisation is for. NTA has not announced any NEET normalisation formula, so anyone selling a "normalisation calculator" right now is guessing. Don't waste study hours on it.

## How to prep for both formats (the lock-in plan)

**1. Keep paper practice as your base.** If 2027 stays OMR, you still need speed and accuracy with a pen. Keep solving PYQs and chapter tests on paper.

**2. Add one weekly CBT test.** Take a timed chapter test on a laptop or desktop. Phones don't count. Build up to full-length CBT mocks as the exam gets closer.

**3. Practise the skip-flag-return habit.** Don't sink 4 minutes into one question. Move on, mark it, and come back.

**4. Use rough sheets smartly.** Physics, Chemistry and diagrams still need paper. Get comfortable switching between screen and sheet.

**5. Review every mock like a detective.** Tag each lost mark: concept gap, silly mistake, or time management. This is where scores really go up.

**6. Protect your eyes and sleep.** Take screen breaks. No all-nighters before mock tests.

## Does the syllabus change?

The shift to CBT is about the exam **mode**, not about throwing away what you've studied. Keep revising NCERT, keep solving PYQs, and adjust only if NTA's official notification says otherwise.

## Real talk from toppers

Toppers rarely win by panicking about format changes. They win by repeating the basics: strong NCERT, regular tests, honest mistake analysis. On OnlyToppers you can ask a NEET topper how they plan mocks and revision, then copy what fits your style.

## FAQs

### Will NEET 2027 be conducted in CBT mode?
It's not confirmed. CBT has been announced as the direction, but recent reports say 2027 may remain pen-and-paper or hybrid, with full CBT likely from 2028. Wait for NTA's official bulletin.

### Is NEET CBT tougher than pen and paper?
No. The mode changes how you attempt the paper, not how hard the questions are.

### Will the NEET syllabus change because of CBT?
No syllabus change has been announced because of CBT. Follow NTA's official notification.

### Will there be normalisation in NEET?
Not announced. If the exam runs in multiple shifts, NTA will publish the method.

### How should I practise right now?
Keep paper practice as your base and add weekly screen-based chapter tests, then full-length CBT mocks.

### When will the final format be announced?
The reform task force's report is expected by 27 January 2027, and NTA's bulletin should follow. We'll update this post when it does.

## Sources and further reading

- [NEET-UG to shift to CBT from 2027, NTA tells Supreme Court (Deccan Herald)](https://www.deccanherald.com/india/neet-ug-set-to-be-conducted-in-computer-based-test-mode-from-2027-nta-tells-supreme-court-4020703)
- [Southern states oppose CBT shift, full online transition may wait until 2028 (Medical Dialogues)](https://medicaldialogues.in/news/education/medical-admissions/neet-southern-states-oppose-cbt-shift-full-online-transition-may-wait-until-2028-report-182651)
- [NEET may remain pen-and-paper in 2027, CBT likely from 2028 (SeaAndJob)](https://www.seaandjob.com/neet-ug-may-remain-pen-and-paper-exam-in-2027-cbt-likely-from-2028/)

*Always confirm final details on the official NTA website before making plans.*

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Will NEET 2027 be conducted in CBT mode?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "It is not confirmed. CBT has been announced as the direction, but recent reports say 2027 may remain pen-and-paper or hybrid, with full CBT likely from 2028. Wait for NTA's official bulletin."
      }
    },
    {
      "@type": "Question",
      "name": "Is NEET CBT tougher than pen and paper?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No. The mode changes how you attempt the paper, not how hard the questions are."
      }
    },
    {
      "@type": "Question",
      "name": "Will the NEET syllabus change because of CBT?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No syllabus change has been announced because of CBT. Follow NTA's official notification."
      }
    },
    {
      "@type": "Question",
      "name": "Will there be normalisation in NEET?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Not announced. If the exam runs in multiple shifts, NTA will publish the method."
      }
    }
  ]
}
</script>
